import React, { useState, useRef } from "react";
import BookList from "./Components/BookList";
import AuthorInfo from "./Components/AuthorInfo";
import "./styles/styles.css";

function App() {

  const searchRef = useRef(null);
  const [selectedAuthor, setSelectedAuthor] = useState(null);

  const books = [
    {
      title: "The Silent Patient",
      genre: "Thriller",
      author: {
        name: "Alex Michaelides",
        bio: "British-Cypriot novelist and screenwriter best known for psychological thrillers that explore trauma and suspense-driven narratives.",
        topBooks: ["The Silent Patient", "The Maidens", "The Fury"]
      }
    },
    {
      title: "Atomic Habits",
      genre: "Self-help",
      author: {
        name: "James Clear",
        bio: "Writer and speaker focused on habits, decision-making, and continuous improvement. His work centers around practical frameworks for growth.",
        topBooks: ["Atomic Habits", "Better Every Day", "The Habits Guide"]
      }
    }
  ];

  const handleSelect = (book) => {
    setSelectedAuthor(book.author);
  };

  const focusInput = () => {
    if (searchRef.current) {
      searchRef.current.focus();
    }
  };

  return (
    <div className="app-wrapper">
      <div className="container py-5">

        <div className="app-header text-center mb-5">
          <h1 className="main-title">📚 BookVerse</h1>
          <p className="subtitle">
            Discover books and explore the minds behind them
          </p>
        </div>

        {/* Search Section */}
        <div className="search-section d-flex align-items-center justify-content-center mb-5">
          <div className="search-box d-flex w-75">
            <input
              type="text"
              ref={searchRef}
              className="form-control me-2"
              placeholder="Search books..."
            />
            <button
              className="btn btn-success px-4"
              onClick={focusInput}
            >
              Focus
            </button>
          </div>
        </div>

        {/* Books */}
        <BookList books={books} onSelect={handleSelect} />

        {/* Author Details */}
        <AuthorInfo author={selectedAuthor} />

      </div>
    </div>
  );
}

export default App;
