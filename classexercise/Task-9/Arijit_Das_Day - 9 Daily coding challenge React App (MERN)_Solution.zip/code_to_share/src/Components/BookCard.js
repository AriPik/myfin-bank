import React from "react";
import PropTypes from "prop-types";

const BookCard = ({ book, onSelect }) => {
  return (
    <div className="card h-100 shadow-sm">
      <div className="card-body">
        <h5 className="card-title">{book.title}</h5>
        <p className="card-text text-muted">{book.genre}</p>
        <button
          className="btn btn-primary"
          onClick={() => onSelect(book)}
        >
          View Author
        </button>
      </div>
    </div>
  );
};

BookCard.propTypes = {
  book: PropTypes.shape({
    title: PropTypes.string.isRequired,
    genre: PropTypes.string.isRequired,
    author: PropTypes.object.isRequired
  }).isRequired,
  onSelect: PropTypes.func.isRequired
};

export default BookCard;
