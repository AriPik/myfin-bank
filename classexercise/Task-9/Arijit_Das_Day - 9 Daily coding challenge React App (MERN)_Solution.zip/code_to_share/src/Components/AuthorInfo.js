import React, { Component } from "react";

class AuthorInfo extends Component {

  componentDidMount() {
    console.log("AuthorInfo mounted");
  }

  componentDidUpdate(prevProps) {
    if (this.props.author !== prevProps.author && this.props.author) {
      console.log("Author changed:", this.props.author.name);
    }
  }

  render() {
    const { author } = this.props;

    if (!author) {
      return (
        <div className="author-empty text-center mt-5">
          <div className="empty-box p-4">
            <h5 className="mb-2">No Author Selected</h5>
            <p className="text-muted mb-0">
              Click on a book card to explore detailed author information.
            </p>
          </div>
        </div>
      );
    }

    return (
      <div className="author-card mt-5">
        <div className="author-header d-flex align-items-center mb-4">
          <div className="author-avatar">
            {author.name.charAt(0)}
          </div>
          <div>
            <h3 className="mb-1">{author.name}</h3>
            <small className="text-muted">Author Profile</small>
          </div>
        </div>

        <div className="author-bio-section mb-4">
          <h6 className="section-title">Biography</h6>
          <p>{author.bio}</p>
        </div>

        <div className="author-books-section">
          <h6 className="section-title">Top Works</h6>
          <div className="row">
            {author.topBooks.map((book, index) => (
              <div className="col-md-4 mb-3" key={index}>
                <div className="mini-book-card p-3 text-center">
                  {book}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }
}

export default AuthorInfo;
