import React from "react";
import BookCard from "./BookCard";

const BookList = ({ books, onSelect }) => {
  return (
    <div className="row">
      {books.map((book, index) => (
        <div className="col-md-4 mb-3" key={index}>
          <BookCard book={book} onSelect={onSelect} />
        </div>
      ))}
    </div>
  );
};

export default BookList;
